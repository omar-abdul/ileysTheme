<?php
    /**
     * Template to show when there is no content in the loop
     */
?>


<div class="container">
    <div class="mx-auto p-5 text-center">
    
    <h4><?php _e("Oops it seems that there isn't any content to show try searching again",'ileysthem')?></h4>
    
    </div>
</div>